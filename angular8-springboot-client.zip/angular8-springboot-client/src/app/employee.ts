export class Employee {
  id: number;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: boolean;
}
